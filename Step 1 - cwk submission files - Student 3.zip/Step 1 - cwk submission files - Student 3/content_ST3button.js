 //Function executed when clicking Go To Top button to go to top of page
    //Browser's window will scroll to coordinates (0,0) to top left corner of page (bringing to top of page)
    function gotoTop() {
        window.scrollTo(0, 0);
    }